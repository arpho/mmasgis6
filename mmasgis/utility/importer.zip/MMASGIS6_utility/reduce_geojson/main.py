from geoJson import *

print features[0]['geometry']['coordinates'][0][0][0]
f = open('test.py','w')
for i in features:
	f.write(str(i))