import requests
from cap import cap
from regioni import regioni
import json
validate_endpoint = 'http://geojsonlint.com/validate'
good_geojson = '{"type": "Point", "coordinates": [-100, 80]}'
bad_geojson = '{"type": "Rhombus", "coordinates": [[1, 2], [3, 4], [5, 6]]}'

good_request = requests.post(validate_endpoint, data=cap)
bad_request = requests.post(validate_endpoint, data=bad_geojson)

def validate(d):
	return requests.post(validate_endpoint, data=d)

def check_error(v):
	b = False
	if(v['status']==unicode('error')):
		b = True
		return b 
	
b = True
print "cap",validate(cap).json()
print json.loads(cap)
n = 0
"""for d in cap['features']:
	#b*=validate(d)
	v = validate(d)
	b *= check_error(v.json())
	print "evaluated",n
	n +=1"""
g = lambda x:'si' if x else 'no'

print "tutti sbagliati",g(b)
 
	#print "validato",d,b
# {u'status': u'ok'}

# {u'status': u'error', u'message': u'"Rhombus" is not a valid GeoJSON type.'}
