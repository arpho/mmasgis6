#!/usr/bin/python
# -*- coding: utf-8 -*-
from pymongo import Connection
class mongo:
	def __init__(self,db ='mmasgis'):
		self.conn = Connection()
		self.db = self.conn[db]
		self.coll = self.db.owners

	def switch_db(self,db):
		self.db = self.client[db]
		
	def find(self,db,collection,query):
		return self.conn[db][collection].find(query)
def fixEuro(txt):
	out = ''
	for i in txt:
		if i==unichr(128):
			out += '€'
		else:
			out += i 
	return out
m = mongo()
u = m.find('mmasgis','users',{})
query = {}
condizione = {}
condizione['$in'] = [5]
query['codice_regione']= condizione
prov = m.find('mmasgis','province',query)
cod_prov = []
for i in prov:
	cod_prov.append(i['codice'])
	print i['codice']
#print prov

#cod_prov =[i['codice'] for i in prov]
print cod_prov
condizione ={}
condizione['$in'] = cod_prov
query = {}
query['codice_provincia'] = condizione
comuni = m.find('mmasgis','comuni',query)
print "comuni: {0}".format(comuni.count())
istat = [i['tc_comune_id'] for i in comuni]
print len(istat)
#cerco pv
condizione['$in'] = istat
query = {}
query['tc_istat_id'] = condizione
pv = m.find('saloni','pv',query)
print "numero pv :{}".format(pv.count())
query = {}
query['tc_par_id'] = 834
"""regex = {}
regex['$regex']='oltre'
regex['$options'] = 'i'
query['testo'] = regex"""
err = m.find('saloni','tc_par',query)[0]
#a = err['testo'].replace('\u0080', 'â¬')
print err
print 'testo ' +fixEuro(err['testo'])
#print 'â¬'
"""
for i in pv:
	print i"""
"""
istat = [i['tc_comune_id'] for i in comuni]
condizione['$in']= ['95014']
query = {}
query['cap'] = condizione
#pv = m.find('saloni','pv',query)

print len(istat)
#print istat
"""
