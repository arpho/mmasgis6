# -*- encoding: utf-8 -*-
class Collection:
	"""
	astrae il concetto di Collezione
	"""
	def __init__(self,db,collection):
		"""
		@param param: connessione a mongoDb
		@param collection:string: collezione del database che deve essere rappresentata dall'istanza
		"""
		#self.collezione = collection
		self.collection = db[collection]	

	def get_documents(self,query):
		"""ritorna la lista dei documenti contenuta nella collezione
		@return: [{}]
		""" 
		return list(self.collection.find(query))
	
	def set_index(self,i):
		self.collection.ensure_index(i)
	
		
	def push_item(self,_id,item,field):
		print 'push',{'$push':{field:item}},'in ',_id
		self.collection.update({'_id':_id},{'$push':{field:item}})
	
	def insert_single_item(self,item):
		"""
		inserisce un singolo item nella collezione
		@param item:{}
		@return _id: string
		"""
		#print "inserisco", item
		id = self.collection.insert(item)
		return id
	
	def update_field(self,Id,field,value):
		self.collection.update({'_id':Id},{'$set':{field:value}})
		
	def update_document(self,item,_id=''):
		"""aggiorna il documento
		@param {}: record di mongoDb """
		self.collection.update(dict(_id=item.get('_id')),item,False)
	
	def insert_list(self,l):
		"""
		inserisce una lista di documenti nella collezione
		@param :[{string:string}]
		"""
		try:
			self.collection.insert(l)
		except:
			print "problemi inserendo lista in",self.collection
		
	def normalize_item(self,item,model,extra={}):
		"""
		normalizza gli item prima che vengano inseriti nella collezione
		@param: {string.string}
		@param: [string]lista dei campi che ogni documento deve possedere
		@param {string:string}: campi extra appena aggiunti che i documenti devono possedere, come group_id  
		"""
		obj = {}
		s = lambda x:'' if x is None else x 
		for k in model:
			obj[k] = s(item.get(k))
		for k in extra:
			obj[k] = extra[k]
		return obj 
	
	def normalize_collection(self,group_id):
		c = self.get_documents({})
		n = len(c)
		for i in c:
			i = self.normalize_item(i, {'group_id':group_id})
			Collection.update_item(self,i,i.get('_id'))
		return n