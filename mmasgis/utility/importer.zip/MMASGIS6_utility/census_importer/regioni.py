#!/usr/bin/python
# -*- coding: latin-1 -*-
regioni=[(1,"PIEMONTE",12),
(2,"VALLE D'AOSTA",19),
(3,"LOMBARDIA",9),
(4,"TRENTINO-ALTO ADIGE",17),
(5,"VENETO",20),
(6,"FRIULI-VENEZIA GIULIA",6),
(7,"LIGURIA",8),
(8,"EMILIA-ROMAGNA",5),
(9,"TOSCANA",16),
(10,"UMBRIA",18),
(11,"MARCHE",10),
(12,"LAZIO",7),
(13,"ABRUZZO",1),
(14,"MOLISE",11),
(15,"CAMPANIA",4),
(16,"PUGLIA",13),
(17,"BASILICATA",2),
(18,"CALABRIA",3),
(19,"SICILIA",15),
(20,"SARDEGNA",14),
]
#(codice regione,nome,sigla,codice istat per pv)