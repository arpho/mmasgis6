from Db import My_mongoDb
from Relations.Attribut import Attribut
from Relations.Tc_par import Tc_par
from Relations.Parameter import Parameter
from Relations.Tc_par import Tc_mar
from Relations.Brand import Brand 
from Relations.Potential import Potential 
db = My_mongoDb('localhost','saloni')

#r = Attribut('par',Tc_par,db)
pot = Potential(db)
#par = r.get_real_signatures(12)
p = Parameter(db)
mar = Brand(db)
print "parametri"
par1 = p.get_tc(12)
print "potenziali"
pot1 = pot.get_tc(12)
print "brand"
mar = mar.get_tc(int('12'))
print "done"