#! /usr/bin/python
# -*- coding: utf-8 -*-
from pymongo import Connection
from  relations_fixer.utility import Utility 
#from pymongo import MongoClient

"""from Group import Group
from User import User
from Company import Company
from Contact import Contact
"""
from Collection import Collection
from bson.objectid import ObjectId
class Mongo:
	"""astrae la connessione a mongoDb
	"""
	def __init__(self,host = 'localhost',db ='node-mongo-bb'):
		"""
		@param host: default 'localhost'
		@param db:default 'node-mongo-bb'
		"""
		#print "host",host
		#print "db",db
		conn = Connection(host, 27017) 
		#collego al server 
		
		#self.company = Company(conn)
		#self.contact = Contact(conn)
		self.db = conn[db] # connessione al db
		"""
		self.groups = Group(self.db)
		self.contacts = Contact(self.db)
		self.companies = Company(self.db)
		self.users = User(self.db)
		"""
		#self.collection =Collection
		
		
	def getDb(self):
		return self.db
	
	def insert_contact_item(self,item):
		self.contacts.insert_single_item(item)
	
	def update_contact_item(self,item,_id):
		self.contacts.update_item(item,_id)
	
	def insert_companies_list(self,l):
		self.companies.insert_list(l)
		
	def insert_contacts_list(self,l):
		self.contacts.insert_list(l)
	
	def normalize_company(self,c,g):
		return self.company.normalize_item(c,g)
		
	def normalize_customer(self,c,g):
		return self.contact.normalize_customer(c,g)
	
	def get_groups(self,query ={}):
		return self.groups.get_documents(query)
	
	def get_contacts(self,query ={}):
		return self.contacts.get_documents(query)
	
	def get_companies(self,query ={}):
		return self.companies.get_documents(query)
	
	def get_users(self,query ={}):
		return self.users.get_documents(query)
	
	def normalize_customers(self,group_id):
		return self.contacts.normalize_collection(group_id)
	
	def normalize_customers_list(self,l,group_id):
		return self.contacts.normalize_list(l,group_id)
		
	def normalize_companies_list(self,l,group_id):
		return self.companies.normalize_list(l,group_id)
	
	def normalize_companies(self,group_id):
		return self.companies.normalize_collection(group_id)
	
	
class My_mongoDb(Mongo):
	def __init__(self, host,db,collection='pv'):
		Mongo.__init__(self, host, db)
		self.collection = Collection(self.db,collection)
		
	def switch_collection(self,collection):
		self.collection = Collection(self.db,collection)
		
	def insert_single_item(self,i):
		self.collection.insert_single_item(i)

	def push_item(self,_id,item,field):
		self.collection.push_item(_id, item, field)
		
	def update_document(self,item):
		self.collection.update_document(item,)
		
	def update_field(self,Id,field,value):
		self.collection.update_field(Id, field, value)
		
	def insert_items(self,l):
		#print " inserisco {0} elementi".format(len(l))
		self.collection.insert_list(l)
		
	def get_documents(self,query={}):
		return self.collection.get_documents(query)
	
	def make_index(self,collection, index):
		self.switch_collection(collection)
		self.collection.set_index(index)
	