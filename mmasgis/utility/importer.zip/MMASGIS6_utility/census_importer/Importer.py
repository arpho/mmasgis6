#! /usr/bin/python
# -*- coding: utf-8 -*-
from Db import My_mongoDb
from MyDb import MyDb
from MyDb import MyDbHosted
from Relations.Parameter import Parameter
from Relations.Tc_par import Tc_mar
from Relations.Brand import Brand 
from Relations.Potential import Potential 
from bson.objectid import ObjectId
from relations_fixer.utility import Utility
import datetime
class Importer():
	"""
	contiene facility per l'esportazuone dei dati da Mysql a mongoDB
	"""
	def __init__(self,mongo_host,db):
		"""
		@param host: string
		@param censimento: string  in realta rappresenta il database che deve essere creato in mongodb  
		"""
		# mi connetto al database mongodb che deve essere creato
		self.census = My_mongoDb(mongo_host,db)
		self.my = MyDb(db) # mi connetto al db mysql
		self.census_name = db
		self.utility = Utility()
	
	def add_census(self,host):
		"""
		aggiunge il censimento alla lista dei censimenti disponibili in mmasgis
		@param host: string
		"""
		mmasgis = My_mongoDb(host,'mmasgis','censimenti')
		mmasgis.insert_single_item(dict(censimento=self.census_name,date=datetime.datetime.utcnow()))
		
	def make_index(self):
		self.census.make_index('pv', [('pv_id',1),('tc_istat_id',1),('pv',1),('nome1',1)])
		print "creati indici su tabella pv"
		self.census.make_index('rel_pv_mar', [('pv_id',1),('tc_cl_mar_id',1),('tc_mar',1),('referenced_pv',1)])
		print "creato indice su tabella rel_pv_mar"
		self.census.make_index('rel_pv_par', [('pv_id',1),('tc_cl_par_id',1),('tc_par',1),('referenced_pv',1)])
		print "creato indice su tabella rel_pv_par"
		self.census.make_index('rel_pv_pot', [('pv_id',1),('tc_cl_pot_id',1),('tc_pot',1),('referenced_pv',1)])
		print "creato indice su tabella rel_pv_pot"
		
	def import_census(self):
		tables = self.get_tables()
		for i in tables:
			self.import_table(i)
		self.make_index()
		
	def put_parameters(self):
		self.census.switch_collection('pv')
		pv = self.census.get_documents()
		par = Parameter(self.census)
		n = 0
		for p in pv:
			parameters_list = par.get_tc(p['pv_id'])
			
			mongo_parameters =[i.get_real_signature() for i in parameters_list]
			p['parametri'] = mongo_parameters
			self.census.insert_single_item(p)
			n += 1
			print "processed {0} pv".format(n)
				
	def test_put_parameters(self):
		self.census.switch_collection('pv')
		pv = self.census.get_documents()
		#print pv[0]
		p = pv[0]
		par = Parameter(self.census) 
		par_list = par.get_tc(p['pv_id'])
		p_mongo_list = [i.get_real_signature() for i in par_list]
		p['parametri'] = p_mongo_list
		self.census.insert_single_item(p)
		
		
	def import_table(self,tab):
		"""
		esporta gli item di una tabella  Mysql alla corrispondente collezione dimongoDb
		@param tabella: string  
		"""
		self.census.switch_collection(tab)
		l = self.my.getRows(tab)
		for i in l:
			for j in i.iterkeys():
				if type('string')==type(i[j]):
					i[j] = i[j].decode('latin_1')
			self.census.insert_single_item(i)
		print "esportati {0} item da {1}".format(len(l),tab)
		
		
	def get_tables(self):
		"""
		ritorna la lista di tabelle nel database mysql
		@return:[string]
		"""
		l = self.my.get_tables()
		tab = []
		for i in l:
			tab.append(i.values()[0])
		return tab
	
	
class ImporterRefactored(Importer):
	
	def getPotential(self,Id):
		"""ritorna il potenziale di un pv
		@param int:pv_id
		@return: Number """
		
		self.census.switch_collection('rel_pv_pot')
		query = {}
		query['pv_id'] = Id
		query['tc_clpot_id'] = 1
		pot = self.census.get_documents(query)
		potential = None
		if (len(pot)>0):
			potential = pot[0]['valore']
			#print potential
		return potential
	
	def SetPotential(self):
		"""aggiunge il campo potenziale ai documenti di pv"""
		self.census.switch_collection('pv')
		#ottengo l'elenco dei pv
		pvs = self.census.get_documents({})
		for i in pvs:
			pot = self.getPotential(i['pv_id'])
			i['potenziale'] = pot
			self.census.switch_collection('pv') # getPotential ha switchato in rel_pv_pot
			self.census.update_field(i['_id'],'potenziale', pot)
		# aggiorno i documenti in pv
		
	def reassignAttributes(self,pv_id,_id,family):
		"""
		aggiunge i campi referenced_pv e  alla tabella rel_pv_family
		@param pv_id: integer, campo pv_id del pv che viene riassegnato
		@param _id: ObjectId del pv
		@param family: identifica la famiglia di attributi da riassegnare <'par','mar','pot'>
		@note: cambia la collezione in uso in rel_pv_family
		""" 
		self.census.switch_collection('rel_pv_'+family)
		print 'punto alla collezione '+'rel_pv_'+family
		# ottengo la lista delle relazioni
		rel = self.census.get_documents(dict(pv_id=pv_id))
		n = 0 
		for i in rel:
			i['referenced_pv'] = _id
			# print 'aggiorno: '+str(i)
			self.census.update_document(i)
			n += 1
		return n 
		#return rel
		
	def __init__(self,mongo_host,myDb,mongoDb,my_host,my_user,my_pwd, census_label=""):
		"""
		@param  string: host di mongoDb
		@param string: database in myQL 
		@param string: nome assegnato al databse in mongoDb
		@param string: host di mysql
		@param string: utente di mysql
		@param string: password di mysql
		@param string:  etichetta del censimento usata dal client di mmasgis5   
		"""
		Importer.__init__(self, mongo_host, myDb)
		self.my = MyDbHosted(myDb,my_host,my_user,my_pwd)
		self.census_label = census_label
		self.census_name = mongoDb
		self.census = My_mongoDb(mongo_host,mongoDb)
		
	def fixEuroSign(self,collection):
		""" 
		esamina il campo testo dei documenti della collezione e corregge il valore del simbolo €
		@param string:  collezione da esaminare
		"""
		self.census.switch_collection(collection)
		# ottengo i documenti della collezione
		doc = self.census.get_documents({})
		for i in doc:
			a = self.utility.fixEuro(i['testo'])
			i['testo'] = unicode(a)
			self.census.update_document(i) 
		
	def add_census(self,host):
		"""
		aggiunge il censimento alla lista dei censimenti disponibili in mmasgis
		@param host: string
		"""
		mmasgis = My_mongoDb(host,'mmasgis','censimenti')
		mmasgis.insert_single_item(dict(censimento=self.census_name,label=self.census_label,date=datetime.datetime.utcnow()))