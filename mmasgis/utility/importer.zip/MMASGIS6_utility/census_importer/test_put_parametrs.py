from Db import My_mongoDb
import datetime
from MyDb import MyDb
import time
from Importer import Importer
db = 'saloni'
Im = Importer('localhost',db)
mmasgis = My_mongoDb('localhost','mmasgis','censimenti')
#Im.add_census('localhost')
tables = Im.get_tables()
Im.test_put_parameters()