import unittest
from Importer import ImporterRefactored
from bson.objectid import ObjectId

class TestSequenceFunctions(unittest.TestCase):

	def setUp(self):
		myDb = 'saloni' #db in mysql
		#utility = Utility()
		mongoDb = 'saloniEuroOk' # db da creare in mongodb
		labelDb = 'saloni2' #etichetta che viene usata da mmasgis per la selezione del censimento
		mongo_host = 'localhost'
		my_host = 'localhost'
		my_user = 'root'
		my_pwd = 'vilu7240'
		nomeDb = 'saloni' #db in mongodb
		myDb = 'saloni' # non lo usiamo ma Importer non lo sa
		CensusLabel = 'saloni' #etichetta in mmasgis.censimenti come myDb
		#exp = Exporter('saloniEuroOk',myDb,labelDb,mongo_host,my_host,my_user,my_pwd)
		self.Im = ImporterRefactored(mongo_host,myDb,nomeDb,my_host,my_user,my_pwd,CensusLabel)
		"""pvp = self.Im.SetPotential()
		print "numero pv= {0}".format(len(pvp))
		print 'potenziale '+ str(pvp[0]['potenziale'])"""
	
	def testPotenziale(self):
		out = self.Im.getPotential(13162)
		exp = 35.25
		self.assertEqual(out,exp,'potenziale sballato')
		out = self.Im.getPotential(18882)
		exp = 24.63
		
		self.assertEqual(out,exp,'potenziale sballato')
		
	def testAttributes(self):
		out = self.Im.reassignAttributes(28229,ObjectId('51a90d405a0c5e289300db44'),'par')
		query = {}
		condition ={}
		condition['$exists'] = True
		query['pv_id'] = 28229
		query['owner_id'] = condition
		out = self.Im.census.get_documents(query)
		exp = 21
		self.assertEqual(exp, len(out), 'attributi non corrispondenti')