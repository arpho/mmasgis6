#! /usr/bin/python
# -*- coding: utf-8 -*-
""" importiamo un database da mySql a mongoDb"""
from Db import My_mongoDb
import datetime
from MyDb import MyDb
import time
#! /usr/bin/python
# -*- coding: utf-8
from relations_fixer.utility import Utility
from Importer import Importer
from Importer import ImporterRefactored
from Exporter import Exporter

myDb = 'saloni' #db in mysql
utility = Utility()
mongoDb = 'saloni' #da creare in mongodb
labelDb = 'saloni2' #etichetta che viene usata da mmasgis per la selezione del censimento
mongo_host = 'localhost'
my_host = 'localhost'
my_user = 'root'
my_pwd = 'vilu7240'
exp = Exporter(mongoDb,myDb,labelDb,mongo_host,my_host,my_user,my_pwd)



#total_time = time.time()-start_time	
#print "esportate {0} tabelle in ".format(len(tables),total_time)
#print total_time
print 'si parte'
start = time.time()
#exp.export()
exp.setPotential()
stop = time.time()
print 'All Done in {0}'.format((stop-start)/60)
print 'setto i potenziali'
#exp.setPotential()
print 'all done'
