from pymongo import Connection
class mongo:
	"""astrae il concetto di connessione a mongoDb"""
	def __init__(self,db ='mmasgis'):
		"""@param db: string nome del database cui connettersi, mmasgis default """
		self.conn = Connection()
		self.db = self.conn[db]
		self.coll = self.db.owners

	def switch_db(self,db):
		self.db = self.client[db]
		
	def find(self,db,collection,query):
		return self.conn[db][collection].find(query)
		
m = mongo()
#u = m.find('mmasgis','users',{})
query = {}
condizione = {}
condizione['$in'] = [5]
query['codice_regione']= condizione
prov = m.find('mmasgis','province',query)
cod_prov = []
for i in prov:
	cod_prov.append(i['codice'])
	print i['codice']
#print prov

#cod_prov =[i['codice'] for i in prov]
print cod_prov
condizione ={}
condizione['$in'] = cod_prov
query = {}
query['codice_provincia'] = condizione
comuni = m.find('mmasgis','comuni',query)
print "comuni: {0}".format(comuni.count())
istat = [i['tc_comune_id'] for i in comuni]
print len(istat)
#cerco pv
condizione['$in'] = istat
query = {}
query['tc_istat_id'] = condizione
pv = m.find('saloni','pv',query)
print "numero pv :{}".format(pv.count())
"""
for i in pv:
	print i"""

istat = [i['tc_comune_id'] for i in comuni]
condizione['$in']= ['95014']
query = {}
query['cap'] = condizione
#pv = m.find('saloni','pv',query)

print len(istat)
#print istat
"""
