from pymongo import Connection
class Mongo:
	"""astrae il concetto di connessione a mongoDb"""
	def __init__(self,db ='mmasgis'):
		"""@param db: string nome del database cui connettersi, mmasgis default """
		self.conn = Connection()
		self.db = self.conn[db]
		self.coll = self.db.owners

	def switch_db(self,db):
		self.db = self.client[db]
		
	def find(self,db,collection,query):
		return self.conn[db][collection].find(query)
	
	def update(self,db,collection,query,value):
		self.conn[db][collection].update(query,value)
	