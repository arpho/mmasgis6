from Relation_fixer import Relation_maker
from bson.objectid import ObjectId
rm = Relation_maker('saloniTest','par')
rpp = rm.get_rel_pv_par()
#print rm.get_class(19)
#print rm.get_par(400)
#rm.updateRelation(ObjectId("520295095a0c5e2b26140bce"), 315, 13)
rm.makeRelation()
print 'done'
