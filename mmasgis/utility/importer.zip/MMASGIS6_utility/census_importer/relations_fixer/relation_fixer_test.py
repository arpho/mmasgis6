import unittest
from bson.objectid import ObjectId
from Relation_fixer import Relation_maker
from Db import  Mongo

class TestSequenceFunctions(unittest.TestCase):

	def setUp(self):
		self.rm = Relation_maker('saloniTest','par')
	def testClass(self):
		class_par = self.rm.get_class(19)
		self.assertEqual(ObjectId("5202951f5a0c5e2b2617d1c9"), class_par, 'non trovo la classe')
		
	def testPar(self):
		class_par = self.rm.get_par(400)
		self.assertEqual(ObjectId("5202951f5a0c5e2b2617d500"), class_par, 'non trovo il parametro')
		
	def testUpdate(self):
		self.rm.updateRelation(ObjectId("520295095a0c5e2b26140bce"), 315, 13)
		queryPar = dict(tc_par_id=315)
		db = Mongo('saloniTest')
		firstPar = db.find('saloniTest','tc_par',queryPar)[0]['_id']
		queryCheckPar = {}#dict('_id':ObjectId("520295095a0c5e2b26140bce"))
		queryCheckPar['_id'] = ObjectId("520295095a0c5e2b26140bce")
		secondPar = db.find('saloniTest','rel_pv_par',queryCheckPar)[0]['my_par_id']
		self.assertEqual(firstPar, secondPar, 'issue in tc_par_id')
		queryCl = dict(tc_clpar_id=13)
		firstCl = db.find('saloniTest','tc_clpar',queryCl)[0]['_id']
		queryCheckCl = {}
		queryCheckCl['_id'] = ObjectId("520295095a0c5e2b26140bce")
		secondCl = db.find('saloniTest','rel_pv_par',queryCheckPar)[0]['my_clpar_id']
		self.assertEqual(firstCl,secondCl,'classe issue')