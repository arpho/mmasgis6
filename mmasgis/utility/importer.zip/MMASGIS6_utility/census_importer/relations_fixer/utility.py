#! /usr/bin/python
# -*- coding: utf-8 -*-
class Utility:
	def fixEuro(self,txt):
		out = ''
		for i in txt:
			if i==unichr(128):
				out += '€'
			else:
				out += i 
		return out