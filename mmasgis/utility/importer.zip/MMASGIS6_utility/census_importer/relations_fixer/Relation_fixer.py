from Db import  Mongo
from bson.objectid import ObjectId

class Relation_maker:
	""""modifica rel_pv_par aggiungendovi due campi relativi agli _id dei campi tc_par e tc_clpar """
	def __init__(self,db,family):
		"""
		@param string: nome del database su cui agire
		@param string: fammiglia del parametro:<'par','mar','pot'>
		"""
		self.db = Mongo(db)
		self.name_db = db
		self.family = family
		
	def get_class(self,id):
		"""ritorna il campo _id del documento di tc_clpar in cui tc_clpar_id = al parametro
		@param tc_clpar_id: int
		@return: ObjectId """
		oid = self.db.find(self.name_db, 'tc_cl'+self.family, dict(tc_clpar_id=id))[0]
		return oid['_id']
	
	def get_par(self,id):
		"""ritorna il campo _id del documento di tc_par in cui tc_par_id = al parametro
		@param tc_par_id: int
		@return: ObjectId """
		oid = self.db.find(self.name_db, 'tc_'+self.family, dict(tc_par_id=id))[0]
		return oid['_id']
		
	def get_rel_pv_par(self):
		#cerco tutti i rel_pv_par
		rpp = self.db.find(self.name_db,'rel_pv_'+self.family,{})
		return rpp
	
	
	def updateRelation(self,_id,par_id,clpar_id):
		""" modifica il documento di rel_pv_par avente _id
		aggiungendo i campi my_clpar_id e my_par_id con i valori di _id di tc_par_id e tc_clpar_id 
		@param ObjectId: campo _id del documento da modificare in rel_pv_par
		@param int:  par_id
		@param int: clpar_id
		@return: void  
		"""
		clpar_id = self.get_class(clpar_id)
		par_id = self.get_par(par_id)
		value_cl ={}
		value_cl['$set'] = dict(my_clpar_id=clpar_id)
		value_par = {}
		value_par['$set'] = dict(my_par_id =par_id)
		#print value_cl
		self.db.update(self.name_db, 'rel_pv_'+self.family, dict(_id=_id),value_cl )
		self.db.update(self.name_db, 'rel_pv_'+self.family, dict(_id=_id),value_par )
		
	def makeRelation(self):
		rpp = self.get_rel_pv_par()
		for i in rpp:
			par_id = rpp[i]['tc_par_id']
			clpar_id = rpp[i]['tc_clpar_id']
		self.updateRelation(rpp[i]['_id'], rpp[i]['par_id'], rpp[i]['clpar_id'])