from Attribut import Attribut
from Tc_par import Tc_par
class Parameter(Attribut):
	def __init__(self,db):
		Attribut.__init__(self, 'par', Tc_par, db)
		
	def get_tc(self,pv_id):
		"""
		ritorna la lista dei Tc_par relativa al pv ordinati secondo il campo order della tabella tc_cl_par
		@param pv_id: int
		@return: [Tc_par]
		"""
		self.mongo.switch_collection('rel_pv_'+self.cl)
		l = self.mongo.get_documents({'pv_id':pv_id})
		sign =[]
		for i in l:
			tc = self.tc(i['tc_cl{0}_id'.format(self.cl)],i['tc_{0}_id'.format(self.cl)],'classe','valore')
			#print self.get_parameter(tc)
			tc.set_parameter(self.get_parameter(tc))
			#tc.set_valore(i['valore'])
			tc.set_order(self.get_order(tc))
			tc.set_class(self.get_class(tc))
			sign.append(tc)
		sign = sorted(sign,key= lambda tc:tc.get_order())
		"""
		for i in sign:
			print i.get_mongo_signature()"""
		return sign
		
		