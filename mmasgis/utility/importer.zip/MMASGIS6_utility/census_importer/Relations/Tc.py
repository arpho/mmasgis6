class Tc:
	def __init__(self,family,label_cl,label_id):
		self.family = family
		self.cl = None
		self.id = None
		self.order = None
		self.testo_cl = None
		self.cl = None
		self.label_cl = label_cl
		self.label_id = label_id
		self.parameter = None
		
	def set_parameter(self,p):
		self.parameter = p
		
	def get_parameter(self):
		return self.parameter
		
	def get_id(self):
		return self.id
	
	def get_cl_id(self):
		return self.cl
	def set_class(self,cl):
		self.testo_cl = cl 
		
	
	def set_tcClass(self,cl,testo):
		self.testo_cl = testo
		self.cl = cl
		
	def set_tcId(self,Id,testo):
		self.id = Id
		self.testo_id = testo
		
	def set_testo_id(self,t):
		self.testo_id = t
		
	def get_testo_id(self):
		return self.testo_id
	
	def get_testo_cl(self):
		return self.testo_cl
		
	def set_order(self,order):
		self.order = order
		
	def get_order(self):
		return self.order 
		
	def get_real_signature(self):
		signature = dict(tc_cl=int(self.cl),tc_id=int(self.id),order=int(self.order))
		return signature
		
	def get_mongo_signature(self):
		signature = {'tc_cl':self.cl,'tc_id':self.id,self.label_cl:self.testo_cl,self.label_id:self.testo_id,'order':self.order}
		return signature
		
		