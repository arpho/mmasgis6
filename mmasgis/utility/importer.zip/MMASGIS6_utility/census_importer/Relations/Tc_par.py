from Tc import Tc


class Tc_par(Tc):
	def __init__(self,cl,Id,testo_cl,testo_id):
		Tc.__init__(self,'par','classe_parametro','parametro')
		Tc.set_tcClass(self, cl, testo_cl)
		Tc.set_tcId(self, Id, testo_id)
		
	def get_mongo_signature(self):
		signature = {'tc_cl':self.cl,'tc_id':self.id,self.label_cl:self.testo_cl,self.label_id:self.testo_id,'order':self.order,'parametro':self.parameter}
		signature = {}
		signature['tc_cl']=int(self.cl)
		signature['tc_id'] = int(self.id)
		signature[self.label_cl] = str(self.testo_cl)
		signature[self.label_id] = str(self.testo_id) 
		signature['order'] = int(self.order)
		signature['parametro'] = str(self.parameter)
		return signature
	
	def get_real_signature(self):
		return Tc.get_real_signature(self)
	
	def set_order(self,o):
		Tc.set_order(self,o)
		
		
	def set_parameter(self,p):
		Tc.set_parameter(self, p)

class Tc_pot(Tc):
	def __init__(self,cl,Id,testo_cl,testo_id):
		Tc.__init__(self,'pot','classe_potenziale','potenziale')
		#Tc.set_order(self, order)
		Tc.set_tcClass(self, cl, testo_cl)
		Tc.set_tcId(self, Id, testo_id)
		self.valore = None
		
	def set_parameter(self,p):
		Tc.set_parameter(self, p)
		
	def set_valore(self,v):
		self.valore = v
		
	def set_order(self,o):
		Tc.set_order(self,o)
		
	def get_mongo_signature(self):
		signature = {'tc_cl':self.cl,'tc_id':self.id,self.label_cl:self.testo_cl,self.label_id:self.testo_id,'valore':self.valore,'order':self.order}
		return signature
	
class Tc_mar(Tc):
	
	def __init__(self,cl,Id,testo_cl,testo_id):
		Tc.__init__(self, 'mar', 'classe_marca', 'marca')
		Tc.set_tcClass(self, cl, testo_cl)
		Tc.set_tcId(self, Id, testo_id)
		self.order = None
		
	def set_brand(self,p):
		Tc.set_parameter(self, p)
		
	def set_valore(self,v):
		self.valore = v
		
	def set_order(self,o):
		Tc.set_order(self,o)
		
	def get_mongo_signature(self):
		signature = {'tc_cl':self.cl,'tc_id':self.id,self.label_cl:self.testo_cl,self.label_id:self.testo_id,'order':self.order}
		return signature