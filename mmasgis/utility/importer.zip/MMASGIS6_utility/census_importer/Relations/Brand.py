from Attribut import Attribut
from Tc_par import Tc_mar

class Brand(Attribut):
	def __init__(self,db):
		Attribut.__init__(self, 'mar', Tc_mar, db)
		
	def get_tc(self,pv_id):
		"""
		ritorna la lista degli oggetti Tc_mar del pv ordinati secondo il campo order e il campo marca
		@param param: pv_id:int 
		@return [Tc_mar]
		@note: degli oggetti ritornati in mongodb va inserito  il risultato di Tc_pot.get_mongo_signature
		""" 
		self.mongo.switch_collection('rel_pv_'+self.cl)
		l = self.mongo.get_documents({'pv_id':pv_id})
		sign =[]
		for i in l:
			tc = self.tc(i['tc_cl{0}_id'.format(self.cl)],i['tc_{0}_id'.format(self.cl)],'classe','label_id')
			#print self.get_parameter(tc)
			tc.set_testo_id(self.get_parameter(tc))
			tc.set_order(self.get_order(tc))
			tc.set_class(self.get_class(tc))
			sign.append(tc)
		sign = sorted(sign,key= lambda tc:(tc.get_order(),tc.get_testo_id(),tc.get_testo_cl()))
		"""for i in sign:
			print i.get_mongo_signature()"""
		return sign