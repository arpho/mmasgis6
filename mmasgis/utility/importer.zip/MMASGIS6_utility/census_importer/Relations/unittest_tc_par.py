import unittest

from Tc_par import Tc_par

class MyTest(unittest.TestCase):
	def setUp(self):
		self.t = Tc_par(1,1,'classe test','parametro_test')
		self.t.set_order(1)
		self.t.set_parameter('parametro_test')
		
	def test_real_signature(self):
		print self.t.get_real_signature()
		self.assertEqual(dict(tc_cl=1,tc_id=1), self.t.get_real_signature(), 'no real signature')
		
	def test_mongo_signature(self):
		print 're',self.t.get_mongo_signature()
		print 'ex',{'tc_cl':1,'tc_id':1,'classe_parametro':'classe test','parametro':'parametro_test','order':1}
		self.assertEqual({'tc_cl':1,'tc_id':1,'classe_parametro':'classe test','parametro':'parametro_test','order':1}, self.t.get_mongo_signature(), 'no mongo signature')