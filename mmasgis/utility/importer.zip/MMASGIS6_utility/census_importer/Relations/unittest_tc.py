import unittest

from Tc import Tc

class MyTest(unittest.TestCase):
	def setUp(self):
		self.tc = Tc('par','testo_cl','testo_id')
		self.tc.set_order(1)
		self.tc.set_tcClass(1, 'testo_cl_settato')
		self.tc.set_tcId(1, 'testo_id_settato')
		
	def test_real_signature(self):
		self.assertEquals(dict(tc_cl=1,tc_id=1), self.tc.get_real_signature(), 'no real signature')
		
	def test_mongo_signature(self):
		self.assertEquals({'tc_cl':1,'tc_id':1,'testo_cl':'testo_cl_settato','testo_id':'testo_id_settato','order':1}, self.tc.get_mongo_signature(), 'no mongo signature')