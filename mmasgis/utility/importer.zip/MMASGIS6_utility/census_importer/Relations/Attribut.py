class Attribut:
	"""
	astrae il concetto  generale di parametri, marche e potenziali, sono tutti attributi di un pv
	"""
	def __init__(self,cl,tc,db):
		self.cl = cl
		self.tc = tc
		self.mongo = db
		
	def get_real_signatures(self,pv_id):
		self.mongo.switch_collection('rel_pv_'+self.cl)
		l = self.mongo.get_documents({'pv_id':pv_id})
		sign =[]
		for i in l:
			tc = self.tc(i['tc_cl{0}_id'.format(self.cl)],i['tc_{0}_id'.format(self.cl)],'classe','valore')
			#print self.get_parameter(tc)
			tc.set_parameter(self.get_parameter(tc))
			tc.set_class(self.get_class(tc))
			print tc.get_mongo_signature()
			sign.append(tc)
		return sign
	
	def get_parameter(self,sign):
		self.mongo.switch_collection('tc_{0}'.format(self.cl))
		#print'sign', sign
		k = 'tc_{0}_id'.format(self.cl)
		query = {k:int(sign.get_id())}
		#query = {'$and':[Id,cl_id]}
		#print 'query',query
		p = self.mongo.get_documents(query)
		return p[0]['testo']
	
	def get_order(self,sign):
		self.mongo.switch_collection('tc_cl{0}'.format(self.cl))
		
		k = 'tc_cl{0}_id'.format(self.cl)
		query = {k:int(sign.get_cl_id())}
		p = self.mongo.get_documents(query)
		return p[0]['ordine']
	
	def get_class(self,sign):
		self.mongo.switch_collection('tc_cl{0}'.format(self.cl))
		
		k = 'tc_cl{0}_id'.format(self.cl)
		query = {k:int(sign.get_cl_id())}
		p = self.mongo.get_documents(query)
		return p[0]['testo']
	