#! /usr/bin/python
# -*- coding: utf-8 -*-
import MySQLdb
import MySQLdb.cursors
class MyDb:
	def __init__(self,db):
		myDb = MySQLdb.connect(user='root', passwd='vilu7240', db=db, cursorclass=MySQLdb.cursors.DictCursor,use_unicode=True)
		self.myCurs = myDb.cursor()
		
	def getRows(self,table):
		self.myCurs.execute("SELECT * FROM "+table)
		return self.myCurs.fetchall()
	
	def get_tables(self):
		self.myCurs.execute("SHOW TABLES") 
		return self.myCurs.fetchall()
	
class MyDbHosted(MyDb):
	"""aggiunge la possibilità di collegarsi ad un database remoto specificando user e password"""
	def __init__(self,db,host,user,pwd):
		MyDb.__init__(self, db)
		myDb = MySQLdb.connect(user=user, passwd=pwd,host=host, db=db, cursorclass=MySQLdb.cursors.DictCursor,use_unicode=True)
		self.myCurs = myDb.cursor()