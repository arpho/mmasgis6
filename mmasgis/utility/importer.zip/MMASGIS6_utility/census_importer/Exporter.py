#! /usr/bin/python
# -*- coding: utf-8 -*-
from Db import My_mongoDb
import datetime
from MyDb import MyDb
import time

from relations_fixer.utility import Utility
from Importer import Importer
from Importer import ImporterRefactored
class Exporter:
	def __init__(self,nomeDb,myDb,CensusLabel,mongo_host,my_host,my_user,my_pwd):
		"""
		esegue le operazioni per importare un censimento da mysql in mmasgis5
		@param string: nome che assumerà il db in mongoDb
		@param string: nome del database in mysql
		@param string: nome  visualizzato in mmasgis 5   
		@param string: host di mongodb 
		@param string: host di mysql
		@param string: utente mysql
		@param string: password mysql  
		"""
		self.myDb = myDb
		self.mongoDb = nomeDb
		self.labelDb = CensusLabel
		self.Im = ImporterRefactored(mongo_host,myDb,nomeDb,my_host,my_user,my_pwd,CensusLabel)
		
	def reassignAllAttributes(self):
		""" riassegna gli attributi, parametri, potenziali e marchi per ogni pv nel censimento"""
		#ottengo la lista dei pv
		self.Im.census.switch_collection('pv') # punto alla collezione pv
		pv = self.Im.census.get_documents() # per default ritorna tutti i documenti
		n = 0
		par = 0
		pot = 0
		mar = 0
		for i in pv:
			print 'riassegno {0}'.format(i['pv_id'])
			print 'riassegno i parametri di {0}'.format(i['pv_id'])
			par += self.Im.reassignAttributes(i['pv_id'],i['_id'], 'par') #riassegno i parametri
			print 'riassegno i poteniali di {0}'.format(i['pv_id'])
			pot += self.Im.reassignAttributes(i['pv_id'],i['_id'], 'pot') #riassegno i potenziali
			print 'riassegno i marchi di {0}'.format(i['pv_id'])
			mar += self.Im.reassignAttributes(i['pv_id'],i['_id'], 'mar') # riassegno i marchi
			n += 1
		print 'ho riassegnato {0} pv'.format(n)
		print 'ho riassegnato {0} parametri'.format(par)
		print 'ho riassegnato {0} potenziali'.format(pot)
		print 'ho riassegnato {0} marchi'.format(mar)
		
		
	def export(self):
		tables = self.Im.get_tables()
		for i in tables:
			self.Im.import_table(i)
		#creo gli indici nel nuovo database
		print 'creo gli indici su '+self.mongoDb
		self.Im.make_index()
		print 'corrego il simbolo € in tc_par'
		self.Im.fixEuroSign('tc_par')
		print 'corrego il simbolo € in tc_clpot'
		self.Im.fixEuroSign('tc_clpot')
		print 'assegno i potenziali ai pv'
		self.setPotential()
		print 'riassegno gli attributi'
		self.reassignAllAttributes()
		print "*"*20
		
		
	def setPotential(self):
		self.Im.SetPotential()